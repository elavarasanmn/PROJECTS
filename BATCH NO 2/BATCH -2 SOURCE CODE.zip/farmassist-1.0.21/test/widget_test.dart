import 'package:flutter_test/flutter_test.dart';

void main() {
  test('mock test', () {
    int i = 1;
    expect(i, 1);
  });
}
