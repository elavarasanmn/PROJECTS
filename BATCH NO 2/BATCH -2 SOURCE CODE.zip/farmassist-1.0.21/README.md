# Farmassist

Precision farming application.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

# General Summary
Please refer to [Effective Dart: Style](https://dart.dev/guides/language/effective-dart/style) for naming guide.
All the code are basically located inside the *lib* folder.

## Important Packages
1. ui = separate each page's code into this package.
2. components = if there are some reusable components, can put it here.

## Important Files
1. main.dart = dart file that contains the app layout (scaffold and bottom nav)