class Constant {
  static const String newsApiKey = 'fbaab164d1f44f429c232b5c8d8d3791';
  static const String baseUrl = 'https://newsapi.org/v2/';
  static const String topHeadLine = '/top-headlines';
}
