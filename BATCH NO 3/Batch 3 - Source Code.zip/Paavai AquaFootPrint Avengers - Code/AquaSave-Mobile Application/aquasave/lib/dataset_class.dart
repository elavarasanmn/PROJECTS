class DataSet {
  String districtName;
  String state;
  String levelOf2025;
  String situation;

  DataSet({
    required this.districtName,
    required this.state,
    required this.levelOf2025,
    required this.situation,
  });

  factory DataSet.fromJson(Map<String, dynamic> json) => DataSet(
    districtName: json["DISTRICT NAME"],
    state: json["STATE"],
    levelOf2025: json["LEVEL OF 2025"],
    situation: json["SITUATION"],
  );

  Map<String, dynamic> toJson() => {
    "DISTRICT NAME": districtName,
    "STATE": state,
    "LEVEL OF 2025": levelOf2025,
    "SITUATION": situation,
  };
}