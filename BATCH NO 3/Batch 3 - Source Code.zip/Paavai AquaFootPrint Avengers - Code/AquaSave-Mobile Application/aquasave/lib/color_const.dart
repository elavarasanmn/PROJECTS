import 'dart:ui';

class ColorSheet {

  static Color mainColorGreen = const Color(0xFF008525);
  static Color bgGrey = const Color(0xFFECECEC);
  static Color white = const Color(0xFFFFFFFF);
  static Color black = const Color(0xFF000000);
  static Color sliderGrey = const Color(0xFF777777);
  static Color hintStyle = const Color(0xFF939393);
}