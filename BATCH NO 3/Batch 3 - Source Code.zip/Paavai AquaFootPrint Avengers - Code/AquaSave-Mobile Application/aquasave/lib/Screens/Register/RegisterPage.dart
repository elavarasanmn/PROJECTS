import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../color_const.dart';
import '../Login/LoginPage.dart';

class Registerscreen extends StatefulWidget {
  const Registerscreen({super.key});

  @override
  State<Registerscreen> createState() => _RegisterscreenState();
}

class _RegisterscreenState extends State<Registerscreen> {
  final userNameController=TextEditingController();
  final emailIdController=TextEditingController();
  final passwordController=TextEditingController();
  final confirmPassController=TextEditingController();
  final formKey = GlobalKey<FormState>();
  bool visiblity  = true;
  bool confvisiblity  = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.only(left: 14,right: 14),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                const SizedBox(
                  height: 30,
                ),
                Container(
                    alignment: Alignment.center,
                    child: Text(
                      'Aqua Save',
                      style: GoogleFonts.lora(
                          fontSize: 16,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    )),
                // const SizedBox(
                //   height: 20,
                // ),
                Image.asset('assets/logo.png',height: 200,),
                const SizedBox(
                  height: 20,
                ),

                Column(
                  children: [
                    Row(
                      children: [
                        Text("Username",style: TextStyle(color: Color(0xff000000),fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: userNameController,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.green), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        hintText:"enter the username",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter valid username';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Text("Email",style: TextStyle(color: Color(0xff000000),fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: emailIdController,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.green), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        hintText:"enter the email",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                      ),
                      validator: (value) {
                        if (value!.isEmpty ||
                            !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                .hasMatch(value)) {
                          return 'Enter a valid email!';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Text("Password",style: TextStyle(color: ColorSheet.black,fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: passwordController,
                      obscureText: visiblity,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        hintText:"Enter the Password",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                        suffixIcon: IconButton(onPressed: (){
                          setState(() {
                            visiblity==false?(visiblity=true):(visiblity=false);
                          });
                        }, icon: Icon(visiblity?Icons.visibility:Icons.visibility_off_rounded),),
                      ),

                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'This field is required';
                        }
                        if (value.trim().length < 8) {
                          return 'Password must be at least 8 characters in length';
                        }
                        // Return null if the entered password is valid
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Text("Confirm password",style: TextStyle(color: ColorSheet.black,fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: confirmPassController,
                      obscureText: confvisiblity,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        hintText:"Enter the confirm password",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                        suffixIcon: IconButton(onPressed: (){
                          setState(() {
                            confvisiblity==false?(confvisiblity=true):(confvisiblity=false);
                          });
                        }, icon: Icon(confvisiblity?Icons.visibility:Icons.visibility_off_rounded),),
                      ),

                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'This field is required';
                        }
                        if (value.trim().length < 8) {
                          return 'Password must be at least 8 characters in length';
                        }
                        if(value !=passwordController.text){
                          return 'Confirm password not matching';
                        }
                        // Return null if the entered password is valid
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                InkWell(
                    onTap: ()async{
                      if(formKey.currentState!.validate()){
                        try {
                          UserCredential result = await FirebaseAuth.instance
                              .createUserWithEmailAndPassword(
                              email: emailIdController.text,
                              password: passwordController.text);
                          User? user = result.user;
                          user?.updateProfile(
                              displayName: userNameController.text);
                          Future.delayed(Duration.zero,(){
                            Navigator.pop(context);
                          });
                          Fluttertoast.showToast(msg: 'Registered Successfully',backgroundColor: Colors.green);
                        }catch(e){
                          Fluttertoast.showToast(msg: "$e",backgroundColor: Colors.red);
                        }
                      }
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(builder: (context) => const Loginscreen()),
                      // );
                    },
                    child: Container(
                      height: 45,

                      decoration: BoxDecoration(
                          color: ColorSheet.mainColorGreen,
                          borderRadius: BorderRadius.circular(15)
                      ),
                      child: Center(child:
                      Text("Register",style: TextStyle(color: ColorSheet.white,fontSize: 14,fontWeight: FontWeight.w600),),
                      ),
                    )
                ),
                const SizedBox(
                  height: 18,
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 22,
                    ),
                    Text(
                      'Already have an account ?',
                      style: TextStyle(color: ColorSheet.black,fontSize: 14),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const Loginscreen()),
                        );
                      },
                      child: Text(
                        'Log In',
                        style: TextStyle(color: ColorSheet.mainColorGreen,fontSize: 14,),
                      ),
                    ),

                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );

  }
}
