import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../color_const.dart';
import '../Register/RegisterPage.dart';
import '../home/homePage.dart';

class Loginscreen extends StatefulWidget {
  const Loginscreen({super.key});

  @override
  State<Loginscreen> createState() => _LoginscreenState();
}

class _LoginscreenState extends State<Loginscreen> {
  final emailIdController=TextEditingController();
  final passwordController=TextEditingController();
  final formKey = GlobalKey<FormState>();
  bool visiblity  = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.only(left: 14,right: 14),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                const SizedBox(
                  height: 50,
                ),
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset('assets/logo.png',height: 20,),
                    Container(
                        alignment: Alignment.center,
                        child: Text(
                          'Aqua save',
                          style: GoogleFonts.lora(
                              fontSize: 16,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Image.asset('assets/logo.png',height: 250,),
                const SizedBox(
                  height: 20,
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Text("Email",style: TextStyle(color: Color(0xff000000),fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: emailIdController,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.green), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        hintText:"enter the email",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                      ),
                      validator: (value) {
                        if (value!.isEmpty ||
                            !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                .hasMatch(value)) {
                          return 'Enter a valid email!';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Text("Password",style: TextStyle(color: ColorSheet.black,fontSize: 14,fontWeight: FontWeight.w600),),
                        const Text('*',style: TextStyle(color: Colors.red,fontSize: 14,fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8,),
                    TextFormField(
                      controller: passwordController,
                      obscureText: visiblity,
                      decoration: InputDecoration(
                        focusedBorder:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ) ,
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        border:OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: ColorSheet.mainColorGreen), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),

                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(width: 1, color: Colors.red), //<-- SEE HERE
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        hintText:"Enter the Password",hintStyle: TextStyle(color: ColorSheet.hintStyle,fontSize: 12),
                        contentPadding: const EdgeInsets.only(left: 15,top: 15,bottom: 15),
                        suffixIcon: IconButton(onPressed: (){
                          setState(() {
                            visiblity==false?(visiblity=true):(visiblity=false);
                          });
                        }, icon: Icon(visiblity?Icons.visibility:Icons.visibility_off_rounded),),
                      ),

                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'This field is required';
                        }
                        if (value.trim().length < 8) {
                          return 'Password must be at least 8 characters in length';
                        }
                        // Return null if the entered password is valid
                        return null;
                      },
                    ),
                    const SizedBox(height: 14,),
                  ],
                ),
                // Padding(
                //   padding:
                //   const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                //   child: TextFormField(
                //     controller: emailIdController,
                //     style:const TextStyle(
                //       color: Colors.black,
                //       fontWeight: FontWeight.w500
                //     ),
                //
                //     decoration: InputDecoration(
                //         enabledBorder: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(5),
                //             borderSide: const BorderSide(
                //                 color: Colors.black, width: 1.5)),
                //         focusedBorder: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(5),
                //             borderSide: const BorderSide(
                //                 color: Colors.black, width: 1.5)),
                //         errorBorder: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(5),
                //             borderSide: const BorderSide(
                //                 color: Colors.black, width: 1.5)),
                //         border: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(5),
                //             borderSide: const BorderSide(
                //                 color: Colors.black, width: 1.5)),
                //         // labelText: 'Username',
                //         labelStyle: const TextStyle(color: Colors.black),
                //         hintText: 'Enter the username',
                //         hintStyle: const TextStyle(color: Colors.black),
                //       filled: true,
                //       fillColor: const Color.fromRGBO(224,251,252,1),
                //
                //     ),
                //     validator: (value) {
                //       if (value == null || value.isEmpty) {
                //         return 'Please enter your Email';
                //       }
                //       return null;
                //     },
                //   ),
                // ),
                // const SizedBox(
                //   height: 20,
                // ),
                // Container(
                //   alignment: Alignment.centerLeft,
                //   padding:  const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
                //   child: Text('Password', style:GoogleFonts.poppins(
                //       fontSize: 12,
                //       color: Colors.white,
                //       fontWeight: FontWeight.bold
                //   ) ),
                // ),
                // Padding(
                //   padding:
                //   const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                //   child: TextFormField(
                //     controller: passwordController,
                //     style:const TextStyle(
                //         color: Colors.black,
                //         fontWeight: FontWeight.w500
                //     ),
                //     decoration: InputDecoration(
                //       enabledBorder: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(5),
                //           borderSide:
                //           const BorderSide(color: Colors.black, width: 1.5)),
                //       focusedBorder: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(5),
                //           borderSide:
                //           const BorderSide(color: Colors.black, width: 1.5)),
                //       errorBorder: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(5),
                //           borderSide:
                //           const BorderSide(color: Colors.black, width: 1.5)),
                //       border: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(5),
                //           borderSide:
                //           const BorderSide(color: Colors.black, width: 1.5)),
                //       // labelText: 'Password',
                //       labelStyle: const TextStyle(color: Colors.black),
                //       hintText: 'Enter the password',
                //       hintStyle: const TextStyle(color: Colors.black),
                //       filled: true,
                //       fillColor: const Color.fromRGBO(224,251,252,1),
                //       // suffixIcon: (eye == true)
                //       //     ? Icon(Icons.visibility)
                //       //     : Icon(Icons.visibility_off),
                //     ),
                //     validator: (value) {
                //       if (value == null || value.isEmpty) {
                //         return 'Please enter your Password';
                //       }
                //       return null;
                //     },
                //   ),
                // ),
                // const SizedBox(
                //   height: 10,
                // ),

                Container(
                    alignment: Alignment.centerLeft,
                    padding:  const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
                    child: Text(
                      'Forgot Password ?',
                      style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    )),
                const SizedBox(
                  height: 22,
                ),
                InkWell(
                    onTap: ()async{
                      FocusScope.of(context).requestFocus();
                      if(formKey.currentState!.validate()){
                        UserCredential result=await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailIdController.text, password: passwordController.text);
                        if(result.user!=null){
                          Future.delayed(Duration.zero,(){
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) =>  Homescreen(currentUser :result.user)),
                            );
                          });
                          Fluttertoast.showToast(msg: "Logged In Successfully",backgroundColor: Colors.green);
                        }else{
                          Fluttertoast.showToast(msg: "Network Issue Unable to Login",backgroundColor: Colors.red);
                        }
                      }


                    },
                    child: Container(
                      height: 45,

                      decoration: BoxDecoration(
                          color: ColorSheet.mainColorGreen,
                          borderRadius: BorderRadius.circular(15)
                      ),
                      child: Center(child:
                      Text("Login",style: TextStyle(color: ColorSheet.white,fontSize: 14,fontWeight: FontWeight.w600),),
                      ),
                    )
                ),
                const SizedBox(height: 20,),
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Does not have an account?",style: TextStyle(color: ColorSheet.black,fontSize: 14,fontWeight: FontWeight.w400),),
                    InkWell(onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const Registerscreen()),
                      );
                    },
                        child: Text("Register",style: TextStyle(color:ColorSheet.mainColorGreen,fontSize: 16,fontWeight: FontWeight.w400))),
                  ],
                ),
                // InkWell(
                //   onTap: ()async{
                //     FocusScope.of(context).requestFocus();
                //     if(formKey.currentState!.validate()){
                //
                //       UserCredential result=await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailIdController.text, password: passwordController.text);
                //       if(result.user!=null){
                //         Future.delayed(Duration.zero,(){
                //           Navigator.push(
                //             context,
                //             MaterialPageRoute(builder: (context) =>  Homescreen(currentUser :result.user)),
                //           );
                //         });
                //         Fluttertoast.showToast(msg: "Logged In Successfully",backgroundColor: Colors.green);
                //       }else{
                //         Fluttertoast.showToast(msg: "Network Issue Unable to Login",backgroundColor: Colors.red);
                //       }
                //     }
                //
                //
                //   },
                //   child: Container(
                //     width: 100,
                //     height: 40,
                //     decoration: BoxDecoration(
                //         borderRadius: BorderRadius.circular(25),
                //         color:  const Color.fromRGBO(25,162,229,1),
                //         boxShadow: const [
                //           BoxShadow(
                //               blurRadius: 2,
                //               offset: Offset(0,2),
                //               color: Colors.black12
                //
                //           )
                //         ]
                //     ),
                //     child: const Align(
                //       alignment: Alignment.center,
                //       child: Text(
                //         'LOG IN',
                //         textAlign: TextAlign.center,
                //         style: TextStyle(
                //           color: Colors.white,
                //
                //           fontWeight: FontWeight.bold,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                // const SizedBox(
                //   height: 18,
                // ),
                //
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.start,
                //   children: [
                //     const SizedBox(
                //       width: 22,
                //     ),
                //     Text(
                //       'Do not have an account ?',
                //       style: GoogleFonts.poppins(
                //           fontSize: 12,
                //           color: Colors.white,
                //           fontWeight: FontWeight.normal),
                //     ),
                //     const SizedBox(
                //       width: 5,
                //     ),
                //     InkWell(
                //       onTap: (){
                //         Navigator.pushReplacement(
                //           context,
                //           MaterialPageRoute(builder: (context) => const Registerscreen()),
                //         );
                //       },
                //       child: Text(
                //         'Register Now',
                //         style: GoogleFonts.poppins(
                //             fontSize: 14,
                //             color: Colors.white,
                //             fontWeight: FontWeight.bold),
                //       ),
                //     ),
                //
                //   ],
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
