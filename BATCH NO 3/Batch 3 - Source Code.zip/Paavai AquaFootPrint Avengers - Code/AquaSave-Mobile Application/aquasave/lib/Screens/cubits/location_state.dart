part of 'location_cubit.dart';

abstract class LocationState extends Equatable {
  const LocationState();
}

class LocationInitial extends LocationState {
  @override
  List<Object> get props => [];
}
class LocationLoading extends LocationState {
  @override
  List<Object> get props => [];
}
class LocationSuccess extends LocationState {
  const LocationSuccess( {this.districtName, this.currentAddress});
 final String? districtName;
 final  String? currentAddress;
  @override
  List<Object> get props => [districtName!,currentAddress!];
}
class LocationFailed extends LocationState {
  @override
  List<Object> get props => [];
}
