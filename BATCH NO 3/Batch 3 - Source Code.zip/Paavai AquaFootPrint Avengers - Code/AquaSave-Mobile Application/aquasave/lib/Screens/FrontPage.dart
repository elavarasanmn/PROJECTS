import 'package:aquvasave/Screens/Login/LoginPage.dart';
import 'package:aquvasave/Screens/Register/RegisterPage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../color_const.dart';

class Frontscreen extends StatefulWidget {
  const Frontscreen({super.key});

  @override
  State<Frontscreen> createState() => _FrontscreenState();
}

class _FrontscreenState extends State<Frontscreen> {
  @override
  Widget build(BuildContext context) {
    var screenWidth=MediaQuery.of(context).size.width;
    var screenHeight=MediaQuery.of(context).size.height;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(left: 14,right: 14),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height:screenHeight*0.14,),
                SizedBox(height : screenHeight*0.260,
                    width:screenWidth*0.490,
                    child: Image(image: AssetImage("assets/logo.png",),fit: BoxFit.cover,)),
                SizedBox(height:screenHeight*0.04,),
                Text("Welcome to Aquasave!" ,textAlign: TextAlign.justify,style: TextStyle(color: Colors.black,fontSize: 30, fontWeight: FontWeight.bold),),
                SizedBox(height:screenHeight*0.005,),
                Text("Login or register to get personalize water scarcity and conservation tips",textAlign: TextAlign.center,style: TextStyle(color: Color(
                    0xff6e6e6e),fontSize: 16, fontWeight: FontWeight.w500),),
                SizedBox(height:screenHeight*0.07,),
                InkWell(
                  onTap: (){
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const Registerscreen()),
                    );
                  },
                  child: Container(
                    height: 45,
                    margin:  const EdgeInsets.only(left: 10,right: 10),
                    decoration: BoxDecoration(
                        border:Border.all(width: 1,  color: ColorSheet.mainColorGreen,),

                        borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Register",style: TextStyle(  color:ColorSheet.mainColorGreen,fontSize: 14,fontWeight: FontWeight.w600),)),
                  ),
                ),
                const SizedBox(height: 14,),
                InkWell(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Loginscreen()),
                    );
                    },
                  child: Container(
                    height: 45,
                    margin:  const EdgeInsets.only(left: 10,right: 10),
                    decoration: BoxDecoration(
                        color: ColorSheet.mainColorGreen,
                        borderRadius: BorderRadius.circular(15)
                    ),
                    child: Center(child: Text("Login",style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),)),
                  ),
                ),
              ],
            ),
            // const SizedBox(
            //   height: 50,
            // ),
            // Container(
            //     alignment: Alignment.center,
            //     child: Text(
            //       'Aqua Save',
            //       style: GoogleFonts.lora(
            //           fontSize: 20,
            //           color: Colors.white,
            //           fontWeight: FontWeight.bold),
            //     )),
            // const SizedBox(
            //   height: 20,
            // ),
            // Image.asset('assets/logo.png',height: 200,),
            // const SizedBox(
            //   height: 20,
            // ),
            // Container(
            //   width: 300,
            //     alignment: Alignment.centerLeft,
            //     child: Text(
            //       'Welcome to AquaSave !',
            //       style: GoogleFonts.poppins(
            //           fontSize: 12,
            //           color: Colors.white,
            //           fontWeight: FontWeight.bold),
            //     )),
            // const SizedBox(
            //   height: 10,
            // ),
            // Container(
            //   width: 300,
            //     alignment: Alignment.center,
            //     child: Text(
            //       'Login or Register to got personalized water scarcity alots and conversation tips',
            //       style: GoogleFonts.poppins(
            //           fontSize: 12,
            //           color: Colors.white,
            //           fontWeight: FontWeight.bold),
            //     )),
            // const SizedBox(
            //   height: 30,
            // ),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //   children: [
            //     InkWell(
            //       onTap: (){
            //         Navigator.push(
            //           context,
            //           MaterialPageRoute(builder: (context) => const Loginscreen()),
            //         );
            //       },
            //       child: Container(
            //         width: 100,
            //         height: 40,
            //         decoration: BoxDecoration(
            //             borderRadius: BorderRadius.circular(25),
            //             color: const Color.fromRGBO(224,251,252,1),
            //             boxShadow: const [
            //               BoxShadow(
            //                 blurRadius: 2,
            //                 offset: Offset(0,2),
            //                 color: Colors.black12
            //
            //               )
            //             ]
            //         ),
            //         child: const Align(
            //           alignment: Alignment.center,
            //           child: Text(
            //             'LOG IN',
            //             textAlign: TextAlign.center,
            //             style: TextStyle(
            //               color: Colors.black,
            //
            //               fontWeight: FontWeight.bold,
            //             ),
            //           ),
            //         ),
            //       ),
            //     ),
            //
            //     InkWell(
            //       onTap: (){
            //         Navigator.pushReplacement(
            //           context,
            //           MaterialPageRoute(builder: (context) => const Registerscreen()),
            //         );
            //       },
            //       child: Container(
            //         width: 100,
            //         height: 40,
            //         decoration: BoxDecoration(
            //             borderRadius: BorderRadius.circular(25),
            //             color: const Color.fromRGBO(246,248,247,1),
            //             boxShadow: const [
            //             BoxShadow(
            //                 blurRadius: 2,
            //                 offset: Offset(0,2),
            //                 color: Colors.black12
            //
            //             )]
            //         ),
            //         child: const Align(
            //           alignment: Alignment.center,
            //           child: Text(
            //             'REGISTER',
            //             textAlign: TextAlign.center,
            //             style: TextStyle(
            //               color: Colors.black,
            //               fontWeight: FontWeight.bold,
            //             ),
            //           ),
            //         ),
            //       ),
            //     ),
            //
            //   ],
            // ),
            // const SizedBox(
            //   height: 30,
            // ),
            // Container(
            //   width: 200,
            //   height: 40,
            //   decoration: BoxDecoration(
            //       borderRadius: BorderRadius.circular(25),
            //       color: const Color.fromRGBO(246,248,247,1),
            //       boxShadow: const [
            //         BoxShadow(
            //             blurRadius: 2,
            //             offset: Offset(0,2),
            //             color: Colors.black12
            //
            //         )]
            //   ),
            //   child: const Align(
            //     alignment: Alignment.center,
            //     child: Text(
            //       'Continue as guest',
            //       textAlign: TextAlign.center,
            //       style: TextStyle(
            //         color: Colors.black,
            //         fontWeight: FontWeight.bold,
            //       ),
            //     ),
            //   ),
            // ),

          ],
        ),
      ),
    );
  }
}
