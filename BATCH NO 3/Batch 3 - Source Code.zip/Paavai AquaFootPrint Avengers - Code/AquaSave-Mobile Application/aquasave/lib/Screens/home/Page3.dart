import 'package:aquvasave/dataset_class.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../color_const.dart';
import '../Dashboard/dashboard.dart';

class Thirdscreen extends StatefulWidget {
  const Thirdscreen({super.key, this.particularDataSetList, required this.currentAddress});
  final DataSet? particularDataSetList;
  final String currentAddress;
  @override
  State<Thirdscreen> createState() => _ThirdscreenState();
}

class _ThirdscreenState extends State<Thirdscreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo.png',height: 20,),
            Container(
                alignment: Alignment.center,
                child: Text(
                  'Aqua save',
                  style: GoogleFonts.lora(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                )),
          ],
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left: 14,right: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 20,
              ),
              Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/logo.png',height: 200,),
                ],
              ),
              Row(
                children: [
                  Text(
                    'Location: ',
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w600,color: ColorSheet.mainColorGreen),
                  ),
                  Text(
                    widget.currentAddress,
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
                  ),
                ],
              ),

              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text(
                    'Situation: ',
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w600,color: ColorSheet.mainColorGreen),
                  ),
                  Text(
                    widget.particularDataSetList!.situation,
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
                  ),
                ],
              ),

              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text(
                    'Water level: ',
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w600,color: ColorSheet.mainColorGreen),
                  ),
                  Text(
                    widget.particularDataSetList!.levelOf2025,
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                'You are in an area with water scarcity level of ${widget.particularDataSetList!.levelOf2025}',textAlign: TextAlign.center,
                 style:TextStyle(fontSize: 14,fontWeight: FontWeight.w600,color: ColorSheet.mainColorGreen),
              ),

              const SizedBox(
                height: 30,
              ),

              Text(
                'Tips of tackle it',
                style:TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: ColorSheet.black),
              ),
              const SizedBox(
                height: 20,
              ),

              Text(
                'Reclaimed water. ...',
                style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
              ),
              const SizedBox(
                height: 5,
              ),

              Text(
                'Pollution control & better sewage treatment. ...',
                style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
              ),
              const SizedBox(
                height: 5,
              ),

              Text(
                'Awareness & Education.',
                style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
              ),
              const SizedBox(
                height: 5,
              ),

              Text(
                'Water Conservation.',
                style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.black),
              ),
              const SizedBox(
                height: 30,
              ),

              // InkWell(
              //   onTap: (){
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => const Dashboardscreen()),
              //     );
              //   },
              //   child: Container(
              //     width: 200,
              //     height: 40,
              //     decoration: BoxDecoration(
              //         borderRadius: BorderRadius.circular(25),
              //         color: const Color.fromRGBO(255,183,3,1),
              //         boxShadow: const [
              //           BoxShadow(
              //               blurRadius: 2,
              //               offset: Offset(0,2),
              //               color: Colors.black12
              //
              //           )]
              //     ),
              //     child: const Align(
              //       alignment: Alignment.center,
              //       child: Text(
              //         'Go to Dashboard',
              //         textAlign: TextAlign.center,
              //         style: TextStyle(
              //           color: Colors.black,
              //           fontWeight: FontWeight.bold,
              //         ),
              //       ),
              //     ),
              //   ),
              // ),

            ],
          ),
        ),
      ),
    );
  }
}
