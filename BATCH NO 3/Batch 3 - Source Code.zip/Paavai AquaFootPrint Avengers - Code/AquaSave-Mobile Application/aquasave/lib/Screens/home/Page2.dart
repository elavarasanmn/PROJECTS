import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Dashboard/dashboard.dart';
import 'Page3.dart';

class Secondscreen extends StatefulWidget {
  const Secondscreen({super.key});

  @override
  State<Secondscreen> createState() => _SecondscreenState();
}

class _SecondscreenState extends State<Secondscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color.fromRGBO(18, 35, 123, 1),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            const SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                InkWell(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Dashboardscreen()),
                    );
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(left: 20),
                    child: Icon(
                      Icons.menu_rounded,size: 20,color: Colors.white,
                    ),
                  ),
                ),

                Expanded(
                  flex: 4,
                  child: Container(
                    alignment: Alignment.center,
                    child: Text(
                      'Aqua Save',
                      style: GoogleFonts.lora(
                          fontSize: 20,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Image.asset('assets/logo.png',height: 300,),
            const SizedBox(
              height: 20,
            ),

            Container(
                width: 300,
                alignment: Alignment.center,
                child: Text(
                  'Finding the Location ...',
                  style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: (){
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => const Thirdscreen()),
                // );
              },
              child: Icon(
                Icons.location_on_rounded,size: 40,color: Colors.white,
              ),
            ),

          ],
        ),
      ),
    );
  }
}
