import 'dart:convert';
import 'package:aquvasave/Screens/cubits/location_cubit.dart';
import 'package:aquvasave/color_const.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../dataset_class.dart';
import '../Dashboard/Forums/Communityforum.dart';
import '../Dashboard/Forums/Feedbackforum.dart';
import '../Dashboard/dashboard.dart';
import '../Login/LoginPage.dart';
import 'Page3.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key, this.currentUser});
  final User? currentUser;
  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {

  List<DataSet> dataSetList = [];
  bool isClose = false;
  DataSet? particularDataSetList;

  Future<void> readJson(String? districtName) async {
    final String response = await rootBundle.loadString('assets/dataset.json');
    final data = await json.decode(response);

    for (var element in data) {
      DataSet modelVal = DataSet.fromJson(element);
      dataSetList.add(modelVal);
    }
    final index1 = dataSetList.indexWhere((element) =>
    element.districtName == districtName);
    if (index1 != -1) {
      print("Index $index1: ${dataSetList[index1].levelOf2025}");
      particularDataSetList = dataSetList[index1];
    }
    print(dataSetList[2].districtName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Row(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo.png',height: 20,),
            Container(
                alignment: Alignment.center,
                child: Text(
                  'Aqua save',
                  style: GoogleFonts.lora(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                )),
          ],
        ),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            const SizedBox(
              height: 50,
            ),
            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CommunityforumScreen()),
                );
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: const Color.fromRGBO(246,248,247,1),
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Community Forum',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Feedbackscreen()),
                );
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: const Color.fromRGBO(255,183,3,1),
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Provide Feedback',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: ()async{
                await FirebaseAuth.instance.signOut();
                Future.delayed(Duration.zero,(){
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Loginscreen()));
                });
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Colors.grey.shade300,
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Sign Out',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      body: BlocProvider(
        create: (context) => LocationCubit(),
        child: BlocBuilder<LocationCubit, LocationState>(
          builder: (context, locationState) {
            if (locationState is LocationSuccess) {
              readJson(locationState.districtName);
            }

            return SingleChildScrollView(
              child: Column(
               crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.start,
                  //   children: [
                  //
                  //     InkWell(
                  //       onTap: () {
                  //         Navigator.push(
                  //           context,
                  //           MaterialPageRoute(
                  //               builder: (context) => const Dashboardscreen()),
                  //         );
                  //       },
                  //       child: const Padding(
                  //         padding: EdgeInsets.only(left: 20),
                  //         child: Icon(
                  //           Icons.menu_rounded, size: 20, color: Colors.white,
                  //         ),
                  //       ),
                  //     ),
                  //
                  //     Expanded(
                  //       flex: 4,
                  //       child: Container(
                  //         alignment: Alignment.center,
                  //         child: Text(
                  //           'Aqua Save',
                  //           style: GoogleFonts.lora(
                  //               fontSize: 20,
                  //               color: Colors.white,
                  //               fontWeight: FontWeight.bold),
                  //         ),
                  //       ),
                  //     ),
                  //   ],
                  // ),
                  // const SizedBox(
                  //   height: 20,
                  // ),
                  Image.asset('assets/logo.png', height: 200,),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                      width: 300,
                      alignment: Alignment.center,
                      child: Text(
                        'Welcome back ${widget.currentUser!.displayName} !',
                        style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold),
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Track water scarcity of your area and contribute to conversation effort', textAlign: TextAlign.center,
                    style:TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: ColorSheet.sliderGrey),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  (locationState is LocationLoading)?
                  Column(
                    children: [
                      Icon(Icons.location_on,color:ColorSheet.mainColorGreen,size: 45,),
                      SizedBox(height: 8,),
                      Row(mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 16,width: 16,
                            child: CircularProgressIndicator(color:ColorSheet.mainColorGreen,strokeWidth: 1.5,),
                          ),
                          SizedBox(width: 8,),
                          Text(
                            'Finding best location...',
                            style:  TextStyle(
                              fontSize: 14,
                              color:ColorSheet.mainColorGreen,
                              fontWeight: FontWeight.bold,
                            ),
                          )

                        ],),
                    ],
                  ):
                  InkWell(
                    onTap: () {
                      setState(() {
                        context.read<LocationCubit>().getCurrentPosition();
                      });
                    },
                    child: Container(
                      width: 200,
                      height: 40,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          color: ColorSheet.mainColorGreen,
                          boxShadow: const [
                            BoxShadow(
                                blurRadius: 2,
                                offset: Offset(0, 2),
                                color: Colors.black12

                            )
                          ]
                      ),
                      child:  Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Get Location',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color:ColorSheet.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                     BlocBuilder<LocationCubit, LocationState>(
                      builder: (context, locateState) {
                        if (locateState is LocationSuccess){
                          String currentAddress=locateState.currentAddress!;
                          return InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) =>
                                      Thirdscreen(
                                          particularDataSetList: particularDataSetList,currentAddress:currentAddress)),
                                ).then((value) {
                                  context.read<LocationCubit>().reset();
                                }) ;
                              },
                              child: Container(
                                width: 200,
                                height: 40,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    color: const Color.fromRGBO(255, 183, 3, 1),
                                    boxShadow: const [
                                      BoxShadow(
                                          blurRadius: 2,
                                          offset: Offset(0, 2),
                                          color: Colors.black12

                                      )
                                    ]
                                ),
                                child: const Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Get Started',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              )
                          );
                        }
                       return Container();
                   },
                 ),

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
