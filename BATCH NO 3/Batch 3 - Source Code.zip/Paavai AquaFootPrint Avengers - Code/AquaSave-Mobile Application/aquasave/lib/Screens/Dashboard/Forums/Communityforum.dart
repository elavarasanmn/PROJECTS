import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../color_const.dart';

class CommunityforumScreen extends StatefulWidget {
  const CommunityforumScreen({super.key});

  @override
  State<CommunityforumScreen> createState() => _CommunityforumScreenState();
}

class _CommunityforumScreenState extends State<CommunityforumScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Community form',
          style: GoogleFonts.lora(
              fontSize: 16,
              color: Colors.black,
              fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          const SizedBox(
            height: 50,
          ),
          Image.asset('assets/logo.png',height: 300,),
          const SizedBox(
            height: 20,
          ),

          Container(
            alignment: Alignment.center,
            child: Text(
              'Aqua Save Community' ,
              style:  TextStyle(fontSize: 18,
                color:ColorSheet.mainColorGreen,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(
            height: 30,
          ),

          InkWell(
            child: Container(
              width: 200,
              height: 40,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: ColorSheet.mainColorGreen,
                  boxShadow: const [
                    BoxShadow(
                        blurRadius: 2,
                        offset: Offset(0,2),
                        color: Colors.black12

                    )]
              ),
              child: const Align(
                alignment: Alignment.center,
                child: Text(
                  'Start new Discussion',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),

        ],
      ),
    );
  }
}
