import 'package:aquvasave/color_const.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Feedbackscreen extends StatefulWidget {
  const Feedbackscreen({super.key});

  @override
  State<Feedbackscreen> createState() => _FeedbackscreenState();
}

class _FeedbackscreenState extends State<Feedbackscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Feedback form',
          style: GoogleFonts.lora(
              fontSize: 16,
              color: Colors.black,
              fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            const SizedBox(
              height: 20,
            ),
            Image.asset('assets/logo.png',height: 200,),
            const SizedBox(
              height: 20,
            ),
            Container(
                width: 300,
                alignment: Alignment.center,
                child: Text(
                  'Feedback Forum',
                  style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                )),
            const SizedBox(
              height: 15,
            ),
            Container(
              alignment: Alignment.topLeft,
            padding: const EdgeInsets.only(left: 22),
                child: Text(
                  'What you think of water watches ?',
                  style: TextStyle(
                      fontSize: 14,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                )),
            const SizedBox(
              height: 10,
            ),
             Padding(
              padding: EdgeInsets.symmetric(horizontal: 22,vertical: 8),
              child: TextField(
                // controller: textarea,
                keyboardType: TextInputType.multiline,
                maxLines: 4,
                decoration: InputDecoration(
                    hintText: "Enter Remarks",
                    filled: true,
                    fillColor: ColorSheet.bgGrey,
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2, color: Colors.white)
                    )
                ),

              ),
            ),

            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: (){
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => const Secondscreen()),
                // );
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color:ColorSheet.mainColorGreen,
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child:  Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Submit Feedback',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: ColorSheet.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
                height: 150,
              ),
          ],
        ),
      ),
    );
  }
}
