import 'package:aquvasave/Screens/Dashboard/Forums/Feedbackforum.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Login/LoginPage.dart';
import 'Forums/Communityforum.dart';

class Dashboardscreen extends StatefulWidget {
  const Dashboardscreen({super.key});

  @override
  State<Dashboardscreen> createState() => _DashboardscreenState();
}

class _DashboardscreenState extends State<Dashboardscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        color: const Color.fromRGBO(18, 35, 123, 1),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            const SizedBox(
              height: 50,
            ),
            Container(
              alignment: Alignment.center,
              child: Text(
                'Dashboard',
                style: GoogleFonts.lora(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CommunityforumScreen()),
                );
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: const Color.fromRGBO(246,248,247,1),
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Community Forum',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Feedbackscreen()),
                );
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: const Color.fromRGBO(255,183,3,1),
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Provide Feedback',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: ()async{
                await FirebaseAuth.instance.signOut();
                Future.delayed(Duration.zero,(){
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Loginscreen()));
                });
              },
              child: Container(
                width: 200,
                height: 40,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Colors.grey.shade300,
                    boxShadow: const [
                      BoxShadow(
                          blurRadius: 2,
                          offset: Offset(0,2),
                          color: Colors.black12

                      )]
                ),
                child: const Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Sign Out',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
