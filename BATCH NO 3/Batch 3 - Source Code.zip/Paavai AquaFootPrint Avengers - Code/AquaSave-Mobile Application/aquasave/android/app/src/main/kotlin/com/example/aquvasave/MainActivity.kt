package com.example.aquvasave

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
