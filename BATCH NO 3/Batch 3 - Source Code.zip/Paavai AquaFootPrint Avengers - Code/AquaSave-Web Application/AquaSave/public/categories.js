const categories = {
  Food: [
    {
      name: "Bread",
      image: "/assets/bread.png",
      waterFootprint: { average: 255, range: "180-330 liters" },
      details:
        "Depends on grain type and production methods. Organic wheat generally requires more water.",
    },
    {
      name: "Jam",
      waterFootprint: { average: 350, range: "200-500 liters" },
      details:
        "Varies depending on fruit content and processing. Jams with high water content like strawberry will have a higher footprint than those with denser fruits like mango.",
      image: "/assets/jam.png",
    },
    {
      name: "Apple",
      image: "/assets/apple.png",
      waterFootprint: { average: 95, range: "70-120 liters" },
      details:
        "Water use can vary depending on apple variety, climate, and irrigation practices.",
    },
    {
      name: "Carrot",
      image: "/assets/carrot.png",
      waterFootprint: { average: 40, range: "30-50 liters" },
      details:
        "Commonly grown in various climates, impacting water requirements.",
    },
    {
      name: "Idly",
      image: "/assets/idly.png",
      waterFootprint: { average: 70, range: "50-90 liters" },
      details:
        "Water usage varies based on rice and lentil quantities and production methods.",
    },
    {
      name: "beef",
      image: "/assets/beef.png",
      waterFootprint: { average: 1800, range: "1500-2500 liters"},
      details: "Depend on the breed and growing weather",
    },
    {
      name: "cheese",
      image: "/assets/cheese.png",
      waterFootprint: { average: 1000, range: "800-1200 liters" },
      details:
        "varies according to the type of milk and production method",
    },
    {
      name: "Almond",
      image: "/assets/Almond.png",
      waterFootprint: { average: 1300, range: "1000-1600 liters" },
      details:
        "According to the type of land and quality the varies occurs",
    },
    {
      name: "Rice",
      image: "/assets/Rice.png",
      waterFootprint: { average: 2500, range: "2000-2500 liters" },
      details:
        "Water usage varies based on the variety of crop and cultivating land.",
    },
    {
      name: "Chocolate",
      image: "/assets/Chocolate.png",
      waterFootprint: { average: 1700, range: "1500-2000 liters" },
      details:
        "water usage will be varied according to the types and quality of seeds cultivated.",
    },
    {
      name:"OatsMeal",
      image:"/assets/OatsMeal.png",
      waterFootprint:{ average: 1850,range: "1200-2500 liters"},
      details:
        "Choose oatmeal made with local,organic oats."
    },
    {
      name:"Wheat",
      image:"/assets/wheat.png",
      waterFootprint:{ average: 1300,range: "800-2000 liters"},
      details:
        "Choose whole-wheat bread for its nutritional benefits.Avoid food waste by storing bread properly."
    },
    {
      name: "egg",
      image: "/assets/egg.png",
      waterFootprint:{ average: 3300, range: "2000-4700 liters"},
      details: " Some egg from free-range or caged-free farms.use them effeciently in recipes to avoid waste",
    },
  ],
  Gadgets: [
    {
      name: "Smartphone",
      image: "/assets/smart phone.png",
      waterFootprint: { average: 7600, range: "3600-12000 liters" },
      details:
        "Accounts for water used in mining, manufacturing, and assembly.",
    },
    {
      name: "TV",
      image: "/assets/tv.png",
      waterFootprint: { average: 600, range: "500-700 liters" },
      details:
        "Larger screens and higher resolution TVs typically have higher footprints.",
    },
    {
      name: "Watch",
      image: "/assets/watch.png",
      waterFootprint: { average: 250, range: "200-300 liters" },
      details: "Varies depending on materials and production complexity.",
    },
    {
      name: "Speaker",
      image: "/assets/speaker.png",
      waterFootprint: { average: 180, range: "150-220 liters" },
      details: "Water usage encompasses materials and assembly processes.",
    },
    {
      name: "Laptop",
      image: "/assets/Laptop.png",
      waterFootprint: { average: 13200, range: "7200-20000 liters" },
      details:
        "Water usage varies based on mining, manufacturing, assembling, packaging.",
    },
    {
      name: "Smartwatch",
      image: "/assets/Smartwatch.png",
      waterFootprint: { average: 500, range: "250-750 liters" },
      details:
        "Water usage varies based on the type of leather, materials used. ",
    },
    {
      name: "Portable Charger",
      image: "/assets/Portable Charger.png",
      waterFootprint: { average: 280, range: "140-420 liters" },
      details:
        "Water usage varies based on type of battery, storage capacity.",
    },
    {
      name: "Speaker",
      image: "/assets/speaker.png",
      waterFootprint: { average: 300, range: "150-450 liters" },
      details:
        "Water usage varies based on maanufacturing material, design of the system.",
    },
    {
      name: "Wireless Headphones",
      image: "/assets/Wireless Headphones.png",
      waterFootprint: { average: 350, range: "200-500 liters" },
      details:
        "Water usage varies based on size and material used for manufacturing.",
    },
    {
      name: "Game console",
      image: "/assets/Game console.png",
      waterFootprint: { average: 70, range: "50-90 liters" },
      details:
        "Water usage varies based on manufacturing material and design of the product.",
    },
    {
      name: "electric toothbrush",
      image: "/assets/electric toothbrush.png",
      waterFootprint: { average: 40, range: "20-60 liters" },
      details:
        "turn off water while brushing.us ewater saving modes and brush for the recommeded two minutes",
    },
    {
      name: "projector",
      image: "/assets/projector.png",
      waterFootprint: { average: 2000, range: "1000-3000 liters" },
      details:
        "use the projector only when needed and turn it off when not in use",
    },
    {
      name: "home theatre",
      image: "/assets/home theatre.png",
      waterFootprint: { average: 238, range: "100-500 liters" },
      details:
        "choose a reciever with features you actually use. avoid runing unnecessary features like standby mode.unplug when not in use",
    },
    {
      name: "streaming devices",
      image: "/assets/streaming devices.png",
      waterFootprint: { average: 70, range: "5-50 liters" },
      details:
        "use energy efficient device like chromecast or roku.avoid cssting from a laptop for extended periods.",
    },
  ],
  Cosmetics: [
    {
      name: "Toner",
      image: "/assets/toner.png",
      waterFootprint: { average: 60, range: "50-70 liters" },
      details: "Varies depending on ingredients and production processes.",
    },
    {
      name: "Moisturizer",
      image: "/assets/moisturizer.png",
      waterFootprint: { average: 100, range: "80-120 liters" },
      details:
        "Water-based moisturizers have a higher footprint than oil-based ones.",
    },
    {
      name: "Serum",
      image: "/assets/serum.png",
      waterFootprint: { average: 70, range: "60-80 liters" },
      details:
        "Concentrated formulas often have a higher water footprint per unit volume.",
    },
    {
      name: "Lipbalm",
      image: "/assets/lipbalm.png",
      waterFootprint: { average: 35, range: "30-40 liters" },
      details: "Water usage varies based on ingredients and packaging.",
    },
  ],
  Stationery: [
    {
      name: "Paper",
      image: "/assets/paper.png",
      waterFootprint: { average: 10, range: "5-15 liters" },
      details: "Depends on production processes and pulp sources.",
    },
    {
      name: "Pen",
      image: "/assets/pen.png",
      waterFootprint: { average: 7, range: "5-10 liters" },
      details: "Water usage encompasses material and assembly methods.",
    },
    {
      name: "Eraser",
      image: "/assets/eraser.png",
      waterFootprint: { average: 4, range: "3-5 liters" },
      details: "Varies based on materials and manufacturing methods.",
    },
    {
      name: "Scale",
      image: "/assets/scale.png",
      waterFootprint: { average: 9, range: "8-10 liters" },
      details: "Water usage depends on materials and production methods.",
    },
    {
      name: "Sticky notes",
      image: "/assets/Sticky notes.png",
      waterFootprint: { average: 80, range: "60-100 liters" },
      details:
        "Water usage varies according to the quality of adhesive, paper and size.",
    },
    {
      name: "Marker",
      image: "/assets/Marker.png",
      waterFootprint: { average: 150, range: "100-200 liters" },
      details:
        "Water usage depend on the colour and the type of materila used for manufacturing.",
    },
    {
      name: "Crayon",
      image: "/assets/Crayon.png",
      waterFootprint: { average: 300, range: "200-400 liters" },
      details:
        "Water usage depends on the quality of wax and cover used for it.",
    },
    {
      name: "Glue stick",
      image: "/assets/Glue stick.png",
      waterFootprint: { average: 60, range: "40-80 liters" },
      details:
        "Water usage varies based on amount of adhesiveness used in the product.",
    },
  ],
  Fabric: [
    {
      name: "Denim",
      image: "/assets/denim.png",
      waterFootprint: { average: 1500, range: "1200-1800 liters" },
      details:
        "Water-intensive during cotton cultivation and dyeing processes.",
    },
    {
      name: "Rayon",
      image: "/assets/rayon.png",
      waterFootprint: { average: 800, range: "600-1000 liters" },
      details:
        "Water usage in production varies based on manufacturing methods.",
    },
    {
      name: "Polyester",
      image: "/assets/polyester.png",
      waterFootprint: { average: 900, range: "700-1100 liters" },
      details:
        "Synthetic fiber production requires water for raw material extraction and processing.",
    },
    {
      name: "Cotton",
      image: "/assets/cotton.png",
      waterFootprint: { average: 2700, range: "2200-3200 liters" },
      details:
        "Cotton cultivation is water-intensive, especially in arid regions without sustainable irrigation.",
    },
    {
      name: "Bed sheet",
      image: "/assets/Bed sheet.png",
      waterFootprint: { average: 9750, range: "7000-12000 liters" },
      details:
        "It is varied according to the quality and dense of cotton.",
    },
    {
      name: "Sweatshirt",
      image: "/assets/Sweatshirt.png",
      waterFootprint: { average: 4500, range: "3000-6000 liters" },
      details:
        "Depends on the size and thickness of the material .",
    },
    {
      name: "Leggings",
      image: "/assets/Leggings.png",
      waterFootprint: { average: 3600, range: "2500-4700 liters" },
      details:
        "Water usage varies based on the thickness and colour of the product.",
    },
    {
      name: "Silk scarf",
      image: "/assets/Silk scarf.png",
      waterFootprint: { average: 2700, range: "2000-3500 liters" },
      details:
        "Water usage depends on the colour and thickness of the product .",
    },
    {
      name: "Wool Sweater",
      image: "/assets/Wool Sweater.png",
      waterFootprint: { average: 4900, range: "3500-6300 liters" },
      details:
        "Water usage varies based on the quality and colour.",
    },
  ],
  Hygiene: [
    {
      name: "Toothpaste",
      image: "/assets/toothpaste.png",
      waterFootprint: { average: 50, range: "40-60 liters" },
      details: "Water usage includes ingredients and packaging manufacturing.",
    },
    {
      name: "Shampoo",
      image: "/assets/shampoo.png",
      waterFootprint: { average: 80, range: "60-100 liters" },
      details: "Varies based on formula and bottle size.",
    },
    {
      name: "Soap",
      image: "/assets/soap.png",
      waterFootprint: { average: 30, range: "20-40 liters" },
      details: "Depends on ingredients and production methods.",
    },
    {
      name: "Shower gel",
      image: "/assets/Shower gel.png",
      waterFootprint: { average: 350, range: "250-450 liters" },
      details:
        "Water usage varies based on components and the material used.",
    },
    {
      name: "Shampoo",
      image: "/assets/Shampoo.png",
      waterFootprint: { average: 175, range: "125-225 liters" },
      details:
        "Water usage varies based on chemicals used in it.",
    },
    {
      name: "Contact Lens solution",
      image: "/assets/contact lens solution.png",
      waterFootprint: { average: 245, range: "175-315 liters" },
      details:
        "Water usage varies based on concentration of the chemicals.",
    },
    {
      name: "Hand soap",
      image: "/assets/hand soap.png",
      waterFootprint: { average: 350, range: "250-350 liters" },
      details:
        "Water usage varies based on size and components of the product.",
    },
    {
      name: "Facial Cleaner",
      image: "/assets/facial cleaner.png",
      waterFootprint: { average: 140, range: "100-180 liters" },
      details:
        "Water usage varies based on rice and lentil quantities and production methods.",
    },
  ],
  Beverages: [
    {
      name: "Coffee",
      image: "/assets/coffee.png",
      waterFootprint: { average: 140, range: "100-180 liters" },
      details: "Water usage includes cultivation, processing, and brewing.",
    },
    {
      name: "Tea",
      image: "/assets/tea.png",
      waterFootprint: { average: 30, range: "20-40 liters" },
      details: "Varies based on type and preparation.",
    },
    {
      name: "Milk",
      image: "/assets/milk.png",
      waterFootprint: { average: 1000, range: "800-1200 liters" },
      details: "Includes water used in dairy farming and processing.",
    },
    {
      name: "Bottled Water",
      image: "/assets/bottled water.png",
      waterFootprint: { average: 5, range: "3-8 liters" },
      details: "Water usage includes packaging and bottling processes.",
    },
  ], 
  Appliances: [
    {
      name: "Dishwasher",
      image: "/assets/Dishwasher.png",
      waterFootprint: { average: 80, range: "50-110 liters" },
      details: "Sparkling dishes,water wishes,scrape food first,run only when full,let mindful suds imbue",
    },
    {
      name: "Showerhead",
      image: "/assets/Showerhead.png",
      waterFootprint: { average: 35, range: "80-120 liters" },
      details: "Let the rain fall short,embrace low-flow options,minful showers distort.",
    },
    {
      name: "Refrigerator",
      image: "/assets/Refrigerator.png",
      waterFootprint: { average: 17, range: "10-25 liters" },
      details: "Keep food fresh,water less,defrost regularly,mindful energy caress.",
    },
    {
      name: "Air Conditioner",
      image: "/assets/Air Conditioner.png",
      waterFootprint: { average: 1.5, range: "5-10 liters" },
      details: "Cool comfort whispers its plea,choose energy-efficient models,let mindful breezes decree.",
    },
    {
      name: "Ice Maker",
      image: "/assets/Ice Maker.png",
      waterFootprint: { average: 2, range: "1-3 liters" },
      details: "Chill your drinks with mindful glee,use reusable options,let water wisdom flow,you see.",
    },
    {
      name: "Humidifer",
      image: "/assets/Humidifer.png",
      waterFootprint: { average: 1.5, range: "1-2 liters" },
      details: "Moist air whispers its plea,use only when needed,let mindful breaths set you free.",
    },
    {
      name: "Pool Pump",
      image: "/assets/Pool Pump.png",
      waterFootprint: { average: 300, range: "200-400 liters" },
      details: "Cool dips whisper thier plea,consider pool covers,let mindful splashes decree.",
    },
  ],   

};

module.exports = categories;