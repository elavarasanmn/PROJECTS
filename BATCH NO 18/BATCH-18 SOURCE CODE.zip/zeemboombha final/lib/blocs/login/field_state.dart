class FieldState {
  String error;
  bool enable;

  FieldState({this.error, this.enable = true});
}
