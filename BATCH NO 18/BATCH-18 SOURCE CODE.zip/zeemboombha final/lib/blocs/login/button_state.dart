class ButtonState {
  bool enabled;
  bool loading;

  ButtonState({this.enabled, this.loading});
}
